const twilio = require('twilio');
require('dotenv').config();
const accountSid = process.env.TWILIO_ACCOUNT_STRING || 'TWILIO_ACCOUNT_STRING';
const authToken = 'da757b7bf206c8224eb5554a1e763e70';
const client = twilio(accountSid, authToken);

const sendSMS = async (options) => {
  try {
    await client.messages.create({
      body: options.message,
      from: '+17064683313',
      to: options.phone
    });
    console.log('SMS sent successfully');
  } catch (error) {
    console.error('Error sending SMS:', error);
  }
};

module.exports = sendSMS;
